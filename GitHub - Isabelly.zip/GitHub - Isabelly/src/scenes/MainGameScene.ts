import Phaser from 'phaser';
import { Player } from '../classes/Player';

export class MainGameScene extends Phaser.Scene {
  private player!: Player;
  private farmGrid: Map<string, { state: string, sprite: Phaser.GameObjects.Sprite }> = new Map();
  private tileSize: number = 32;

  constructor() {
    super('MainGameScene');
  }

  create() {
    // Create a basic background with grass tiles
    this.createGround();

    // Add Player
    this.player = new Player(this, 400, 300);

    // Setup input
    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      this.handleInteraction(pointer);
    });

    // Instructions
    this.add.text(10, 10, 'Use as setas para mover. Clique para arar/plantar.', {
      fontSize: '16px',
      color: '#ffffff',
      backgroundColor: '#000000'
    }).setScrollFactor(0);
  }

  private createGround() {
    // For now, let's just fill the screen with grass
    for (let x = 0; x < 800; x += this.tileSize) {
      for (let y = 0; y < 600; y += this.tileSize) {
        this.add.image(x, y, 'tileset', 0).setOrigin(0).setScale(2);
      }
    }
  }

  private handleInteraction(pointer: Phaser.Input.Pointer) {
    const worldX = pointer.worldX;
    const worldY = pointer.worldY;
    
    // Grid alignment
    const gridX = Math.floor(worldX / this.tileSize) * this.tileSize;
    const gridY = Math.floor(worldY / this.tileSize) * this.tileSize;
    const key = `${gridX},${gridY}`;

    if (!this.farmGrid.has(key)) {
      // Till soil
      const sprite = this.add.sprite(gridX, gridY, 'tileset', 1).setOrigin(0).setScale(2);
      this.farmGrid.set(key, { state: 'tilled', sprite });
    } else {
      const tile = this.farmGrid.get(key)!;
      if (tile.state === 'tilled') {
        // Plant something
        tile.state = 'planted';
        tile.sprite.setFrame(2); // Assuming frame 2 is a sprout
      }
    }
  }

  update() {
    this.player.update();
  }
}
